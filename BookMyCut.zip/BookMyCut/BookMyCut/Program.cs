using FireSharp.Config;
using FireSharp.Interfaces;
using BookMyCut.Models;
using FireSharp;

var builder = WebApplication.CreateBuilder(args);

// Firebase configuration
var firebaseConfig = new FirebaseConfig
{
    AuthSecret = "YV2wkpBGOAH0yTRAbyMllw9Ajn7oRhGBEpyvJn8y",
    BasePath = "https://hairapppointment-default-rtdb.firebaseio.com"
};

// Register FirebaseClient with Dependency Injection
builder.Services.AddSingleton<IFirebaseClient>(new FirebaseClient(firebaseConfig));

// Register other services
builder.Services.AddControllersWithViews();

// Register other services
builder.Services.AddScoped<AppointmentService>();
builder.Services.AddScoped<SalonService>();

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
