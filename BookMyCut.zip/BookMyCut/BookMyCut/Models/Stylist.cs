﻿namespace BookMyCut.Models
{
    // Stylist model class
    public class Stylist
    {
        public int StylistId { get; set; } // Unique identifier for the stylist
        public string FirstName { get; set; } // Stylist's first name
        public string LastName { get; set; } // Stylist's last name
        public string Specialty { get; set; } // Stylist's specialty (e.g., color, cut, styling)
        public string Email { get; set; } // Stylist's email address
        public string PhoneNumber { get; set; } // Stylist's phone number
        public DateTime HireDate { get; set; } // Date the stylist was hired
        public DateTime CreatedAt { get; set; } // Record creation timestamp
        public DateTime UpdatedAt { get; set; } // Last update timestamp
    }

}
