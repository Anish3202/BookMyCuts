﻿namespace BookMyCut.Models
{
    public class Appointment
    {
        public string? Id { get; set; } // firebase unique id
        public int AppointmentId { get; set; } // Unique identifier for the appointment
        public int UserId { get; set; } // Foreign key to the User model
        public int StylistId { get; set; } // Foreign key to the Stylist model
        public DateTime AppointmentDate { get; set; } // Date and time of the appointment
        public string? ServiceType { get; set; } // Type of service (e.g., haircut, styling)
        public string? Notes { get; set; } // Additional notes or instru
                                           // ctions
        public DateTime CreatedAt { get; set; } // Record creation timestamp
        public DateTime UpdatedAt { get; set; } // Last update timestamp
        public int SalonId { get; set; }

    }
    public class Salon
    {
        public string? Name { get; set; }
    }
}
