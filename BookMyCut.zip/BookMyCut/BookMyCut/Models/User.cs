﻿namespace BookMyCut.Models
{
    public class User
    {
        public int UserId { get; set; } // Unique identifier for the user
        public string FirstName { get; set; } // User's first name
        public string LastName { get; set; } // User's last name
        public string Email { get; set; } // User's email address
        public string PhoneNumber { get; set; } // User's phone number
        public string PasswordHash { get; set; } // Password hash for authentication
        public DateTime DateOfBirth { get; set; } // User's date of birth
        public DateTime CreatedAt { get; set; } // Account creation timestamp
        public DateTime UpdatedAt { get; set; } // Last update timestamp
    }

}
