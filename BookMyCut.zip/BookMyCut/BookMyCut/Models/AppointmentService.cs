﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookMyCut.Models
{
    public class AppointmentService
    {
        private readonly IFirebaseClient _firebaseClient;

        public AppointmentService(IFirebaseClient firebaseClient)
        {
            _firebaseClient = firebaseClient;
        }

        // Method to add a new appointment
        public async Task AddAppointment(Appointment appointment)
        {
            // Perform the operation synchronously
            var response = _firebaseClient.Set($"Appointments/{appointment.AppointmentId}", appointment);
            await Task.CompletedTask; // This is to match async signature, no actual await needed here
        }

        // Method to get all appointments
        public async Task<List<Appointment>> GetAppointments()
        {
            // Perform the operation synchronously
            var response = _firebaseClient.Get("Appointments");
            var appointments = response.Body;

            var appointmentsDict = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, Appointment>>(appointments);

            return appointmentsDict?.Values.ToList() ?? new List<Appointment>();
        }

        // Method to remove an appointment
        public async Task RemoveAppointment(string id)
        {
            // Perform the operation synchronously
            var response = _firebaseClient.Delete($"Appointments/{id}");
            await Task.CompletedTask; // This is to match async signature, no actual await needed here
        }
    }
}
