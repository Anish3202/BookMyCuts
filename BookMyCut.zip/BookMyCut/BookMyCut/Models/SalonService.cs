﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookMyCut.Models
{
    public class SalonService
    {
        private readonly IFirebaseClient _firebaseClient;

        public SalonService(IFirebaseClient firebaseClient)
        {
            _firebaseClient = firebaseClient;
        }

        // Method to add a new salon
        public async Task AddSalon(Salon salon)
        {
            try
            {
                // Use Task.Run to run the synchronous operation asynchronously
                await Task.Run(() =>
                {
                    var response = _firebaseClient.Push("Salons", salon);

                    if (response.StatusCode != System.Net.HttpStatusCode.OK)
                    {
                        throw new Exception($"Failed to add salon. Status code: {response.StatusCode}");
                    }
                });
            }
            catch (Exception ex)
            {
                // Handle the exception
                throw new Exception("An error occurred while adding the salon", ex);
            }
        }

        // Method to retrieve salons from Firebase
        public async Task<List<KeyValuePair<string, Salon>>> GetSalons()
        {
            try
            {
                // Fetch salons from Firebase
                var response = await Task.Run(() => _firebaseClient.Get("Salon"));

                if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    throw new Exception($"Failed to fetch data from Firebase. Status code: {response.StatusCode}");
                }

                // Check if the response body is empty or null
                if (string.IsNullOrEmpty(response.Body) || response.Body == "null")
                {
                    return new List<KeyValuePair<string, Salon>>();
                }

                var salonsDict = JsonConvert.DeserializeObject<Dictionary<string, Salon>>(response.Body);

                if (salonsDict == null)
                {
                    throw new Exception("Deserialized data is null");
                }

                return salonsDict.Select(item => new KeyValuePair<string, Salon>(item.Key, item.Value)).ToList();
            }
            catch (Exception ex)
            {
                // Log or handle the exception as needed
                throw new Exception("An error occurred while fetching salons", ex);
            }
        }
    }
}
