﻿using FireSharp.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Threading.Tasks;
using BookMyCut.Models;

namespace BookMyCut.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly IFirebaseClient _firebaseClient;
        private readonly AppointmentService _appointmentService;
        private readonly SalonService _salonService;

        // Inject IFirebaseClient via constructor
        public AppointmentController(IFirebaseClient firebaseClient)
        {
            _firebaseClient = firebaseClient;
            _appointmentService = new AppointmentService(_firebaseClient);  // Pass client to service
            _salonService = new SalonService(_firebaseClient);  // Pass client to service
        }

        // Action method to display the list of appointments
        public async Task<IActionResult> Index()
        {
            var appointments = await _appointmentService.GetAppointments();
            return View(appointments);
        }

        // Action method to show the Create view with salon dropdown
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var salons = await _salonService.GetSalons();  // Fetch salons from Firebase
            ViewBag.Salons = new SelectList(salons, "Key", "Value.Name");  // Pass salon list to the view
            return View();
        }

        // Action method to handle the creation of an appointment
        [HttpPost]
        public async Task<IActionResult> Create(Appointment appointment)
        {
            if (ModelState.IsValid)
            {
                await _appointmentService.AddAppointment(appointment);
                return RedirectToAction("Index");  // Redirect to the Index page after creation
            }

            // If the model state is not valid, reload the salon list
            var salons = await _salonService.GetSalons();
            ViewBag.Salons = new SelectList(salons, "Key", "Value.Name");
            return View(appointment);
        }

        // Action method to delete an appointment
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();  // Handle the case where ID is invalid
            }

            await _appointmentService.RemoveAppointment(id);
            return RedirectToAction("Index");  // Redirect to Index after successful deletion
        }

        public async Task<IActionResult> AddTestSalon()
        {
            var salonService = new SalonService(_firebaseClient); // Use your existing SalonService
            await salonService.AddSalon(new Salon { Name = "JAved Habib" }); // Add the Test Salon

            return RedirectToAction("Index"); // Redirect to the Index page after adding the salon
        }

    }
}
